# MEC-Drive

MEC-Drive is a carpool application built for college students (MEC-ians) to promote shared travelling among college students. The application is currently in prototype stage. The application performs basic functionalities like authentication,send a ride request,accepting ride requests,contact students who has accepted the requests and delete ride requests.

<img src="https://raw.githubusercontent.com/JoyalAJohney/MEC-Drive/master/assets/Screenshots/SplashScreen.png" width="300" height="650" title="hover text">   <img src="https://raw.githubusercontent.com/JoyalAJohney/MEC-Drive/master/assets/Screenshots/Login.png" width="300" height="650" title="hover text"> 

<img src="https://raw.githubusercontent.com/JoyalAJohney/MEC-Drive/master/assets/Screenshots/FindRide.png" width="300" height="650" title="hover text">   <img src="https://raw.githubusercontent.com/JoyalAJohney/MEC-Drive/master/assets/Screenshots/OfferRide.png" width="300" height="650" title="hover text">

<img src="https://raw.githubusercontent.com/JoyalAJohney/MEC-Drive/master/assets/Screenshots/Profile.png" width="300" height="650" title="hover text">    <img src="https://raw.githubusercontent.com/JoyalAJohney/MEC-Drive/master/assets/Screenshots/Credits.png" width="300" height="650" title="hover text">

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
